import React from 'react'

const Findboutique = () => {
  return (
    <div>Findboutique</div>
  )
}

export default Findboutique