import React from 'react'

const Luxurycollection = () => {
  return (
    <div>Luxurycollection</div>
  )
}

export default Luxurycollection