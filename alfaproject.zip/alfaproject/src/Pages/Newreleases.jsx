import React from 'react'

const Newreleases = () => {
  return (
    <div>Newreleases</div>
  )
}

export default Newreleases