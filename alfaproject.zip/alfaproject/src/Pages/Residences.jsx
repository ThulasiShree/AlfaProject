import React from 'react'

const Residences = () => {
  return (
    <div>Residences</div>
  )
}

export default Residences