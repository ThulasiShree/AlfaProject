import React from 'react'

const Newsmedia = () => {
  return (
    <div>Newsmedia</div>
  )
}

export default Newsmedia