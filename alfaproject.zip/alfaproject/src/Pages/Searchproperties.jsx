import React from 'react'

const Searchproperties = () => {
  return (
    <div>Searchproperties</div>
  )
}

export default Searchproperties