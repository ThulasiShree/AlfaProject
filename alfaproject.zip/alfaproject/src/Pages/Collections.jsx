import React from 'react'

const Collections = () => {
  return (
    <div>Collections</div>
  )
}

export default Collections