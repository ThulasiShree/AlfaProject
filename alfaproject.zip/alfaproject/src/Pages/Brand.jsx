import React from 'react'

const Brand = () => {
  return (
    <div>Brand</div>
  )
}

export default Brand